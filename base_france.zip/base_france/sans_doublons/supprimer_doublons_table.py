"""
supprime les lignes doublons d'une table
dans un fichier et recopier le fichier obtenu sous le nom copy_ suivi du
 nom initial
"""
def charger(file):

    """
    file = fichier à charger
    """
    fichier = open(file, 'r', encoding= "utf8")
    table = []
    lignes = fichier.readlines()
    lignebis = []
    for i in range(0, len(lignes)):
        ligne = lignes[i]
        ligne = ligne.replace('\n','')
        liste = ligne.split(';')

        # on contrôle qu'aucune donnée n'est manquante
        if ligne not in lignebis:
            lignebis.append(ligne)
    fichier.close()
    recopier(file, lignebis)

def recopier(file, lignebis):
    filebis = "copy_" + file
    fic = open(filebis, 'w', encoding ="utf8")
    for ligne in lignebis:
        m =""
        for item in ligne:
            m = m  + item
        m += "\n"
        fic.write(m)
    fic.close()
